import face_recognition
import imutils
import pickle
import cv2
import numpy as np
import time
import statistics
import tflite_runtime.interpreter as tflite
import matplotlib.pyplot as plt

# Load face recognition encodings
def load_face_encodings(encodings_file_path):
    """Load face encodings from a pickle file."""
    print("[INFO] Loading face encodings and face detector...")
    with open(encodings_file_path, "rb") as file:
        encodings_data = pickle.load(file)
    return encodings_data

# Load object detection model
def load_object_detection_model(model_file_path, labels_file_path):
    """Load the TFLite object detection model and labels."""
    print("[INFO] Loading object detection model...")
    interpreter = tflite.Interpreter(model_path=model_file_path)
    interpreter.allocate_tensors()

    with open(labels_file_path, 'r') as file:
        labels = [line.strip() for line in file.readlines()]

    # Get model input/output details
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    model_input_height, model_input_width = input_details[0]['shape'][1], input_details[0]['shape'][2]
    is_floating_model = (input_details[0]['dtype'] == np.float32)
    input_mean, input_std = 123.5, 123.5

    return interpreter, labels, input_details, output_details, model_input_height, model_input_width, is_floating_model, input_mean, input_std

# Detect faces in the frame
def detect_faces(frame, known_face_data):
    """Detect faces in the frame and return the bounding boxes and names."""
    face_locations = face_recognition.face_locations(frame)
    face_encodings = face_recognition.face_encodings(frame, face_locations)
    detected_faces = []

    for encoding in face_encodings:
        matches = face_recognition.compare_faces(known_face_data["encodings"], encoding)
        face_name = "Unknown"
        
        if True in matches:
            matched_indices = [i for i, match in enumerate(matches) if match]
            name_counts = {}
            for i in matched_indices:
                face_name = known_face_data["names"][i]
                name_counts[face_name] = name_counts.get(face_name, 0) + 1
            
            face_distances = face_recognition.face_distance(known_face_data["encodings"], encoding)
            avg_distance = statistics.mean([dist if dist < 0.5 else 1 for dist in face_distances])
            confidence = (1 - avg_distance) * 100
            face_name = max(name_counts, key=name_counts.get)

        detected_faces.append((face_name, confidence))
    
    return face_locations, detected_faces

# Perform object detection
def detect_objects(frame, interpreter, input_details, output_details, model_input_width, model_input_height, is_floating_model, input_mean, input_std, detection_threshold=0.5):
    """Detect objects in the frame using a TFLite model."""
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    resized_frame = cv2.resize(frame_rgb, (model_input_width, model_input_height))
    input_data = np.expand_dims(resized_frame, axis=0)

    if is_floating_model:
        input_data = (np.float32(input_data) - input_mean) / input_std

    interpreter.set_tensor(input_details[0]['index'], input_data)
    interpreter.invoke()

    detection_boxes = interpreter.get_tensor(output_details[0]['index'])[0]
    class_ids = interpreter.get_tensor(output_details[1]['index'])[0]
    confidence_scores = interpreter.get_tensor(output_details[2]['index'])[0]

    return detection_boxes, class_ids, confidence_scores

# Annotate faces on the frame
def annotate_faces_on_frame(frame, face_locations, detected_faces):
    """Annotate detected faces on the frame with names and confidence."""
    for ((top, right, bottom, left), (name, confidence)) in zip(face_locations, detected_faces):
        label_text = f"{name}: {confidence:.2f}%"
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
        label_y_position = top - 15 if top - 15 > 15 else top + 15
        cv2.putText(frame, label_text, (left, label_y_position), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    return frame

# Annotate objects on the frame
def annotate_objects_on_frame(frame, detection_boxes, class_ids, confidence_scores, labels, detection_threshold=0.5):
    """Annotate detected objects on the frame."""
    for i in range(len(confidence_scores)):
        if confidence_scores[i] > detection_threshold:
            object_label = labels[int(class_ids[i])]
            object_confidence = confidence_scores[i] * 100
            box = detection_boxes[i]

            x1, y1, x2, y2 = int(box[0]), int(box[1]), int(box[2]), int(box[3])
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, f"{object_label}: {object_confidence:.2f}%", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    return frame

# Main function to run the real-time detection
def run_real_time_detection(model_file_path, labels_file_path, encodings_file_path, duration=20, frame_rate=1):
    # Load face encodings and object detection model
    known_face_data = load_face_encodings(encodings_file_path)
    interpreter, labels, input_details, output_details, model_input_height, model_input_width, is_floating_model, input_mean, input_std = load_object_detection_model(model_file_path, labels_file_path)

    # Open the webcam
    print("[INFO] Starting real-time video capture...")
    video_capture = cv2.VideoCapture(0)  # Use 0 for the default webcam

    if not video_capture.isOpened():
        print("[ERROR] Could not open webcam.")
        exit()

    # Get video properties for output
    frame_width = int(video_capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(video_capture.get(cv2.CAP_PROP_FRAME_HEIGHT))

    # Initialize VideoWriter for MP4 output
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    video_writer = cv2.VideoWriter('output.mp4', fourcc, frame_rate, (frame_width, frame_height))

    # Data storage for plotting
    time_stamps = []
    person_presence = {}
    object_presence = {}

    start_time = time.time()

    while time.time() - start_time < duration:
        # Read frame from webcam
        ret, frame = video_capture.read()
        if not ret:
            print("[INFO] Unable to capture frame. Exiting.")
            break

        current_time = time.time() - start_time
        time_stamps.append(current_time)

        # Resize frame to speed up processing
        frame_resized = imutils.resize(frame, width=500)

        # --- Face Detection ---
        face_locations, detected_faces = detect_faces(frame_resized, known_face_data)
        
        # --- Object Detection ---
        detection_boxes, class_ids, confidence_scores = detect_objects(frame_resized, interpreter, input_details, output_details, model_input_width, model_input_height, is_floating_model, input_mean, input_std)

        # Annotate faces and objects
        frame_annotated = annotate_faces_on_frame(frame_resized, face_locations, detected_faces)
        frame_annotated = annotate_objects_on_frame(frame_annotated, detection_boxes, class_ids, confidence_scores, labels)

        # Save the frame to the output video
        video_writer.write(cv2.resize(frame_annotated, (frame_width, frame_height)))

        # Display the frame
        cv2.imshow("Face and Object Detection", frame_annotated)

        # Press 'q' to quit
        if cv2.waitKey(1) == ord('q'):
            break

        # Update person presence data for faces
        for name, confidence in detected_faces:
            if name != "Unknown":
                if name not in person_presence:
                    person_presence[name] = {'times': [], 'confidences': []}
                person_presence[name]['times'].append(current_time)
                person_presence[name]['confidences'].append(confidence)

        # Update object presence data
        for idx, score in enumerate(confidence_scores):
            if score > 0.5:  # Adjust threshold as needed
                object_name = labels[int(class_ids[idx])]
                if object_name not in object_presence:
                    object_presence[object_name] = {'times': [], 'confidences': []}
                object_presence[object_name]['times'].append(current_time)
                object_presence[object_name]['confidences'].append(score * 100)

    # Release webcam and close windows
    video_capture.release()
    video_writer.release()
    cv2.destroyAllWindows()

    # Generate plots
    plot_detection_confidence_levels(time_stamps, person_presence, object_presence)

def plot_detection_confidence_levels(time_stamps, person_presence, object_presence):
    """Generate and save the plot for confidence levels."""
    plt.figure(figsize=(12, 6))

    # Plot person presence
    for person_name, presence_data in person_presence.items():
        plt.plot(presence_data['times'], presence_data['confidences'], label=f"Person: {person_name}")

    # Plot object presence
    for object_name, presence_data in object_presence.items():
        plt.plot(presence_data['times'], presence_data['confidences'], label=f"Object: {object_name}")

    if not person_presence and not object_presence:
        print("[INFO] No data to plot.")
        return

    plt.xlabel("Time (s)")
    plt.ylabel("Confidence Level (%)")
    plt.title("Confidence Levels of Identifications Over Time")
    plt.legend(loc='best')
    plt.grid(True)
    plt.savefig("detection_confidence_plot.png")
    plt.show()

# Entry point to the program
if __name__ == "__main__":
    model_path = 'models/model.tflite'
    labels_path = 'models/labels.txt'
    encodings_path = 'encodings.pickle'
    run_real_time_detection(model_path, labels_path, encodings_path)

